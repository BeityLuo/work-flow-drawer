﻿
// Work_Flow_DrawerView.cpp: CWorkFlowDrawerView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "Work_Flow_Drawer.h"
#endif

#include "Work_Flow_DrawerDoc.h"
#include "Work_Flow_DrawerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CWorkFlowDrawerView

IMPLEMENT_DYNCREATE(CWorkFlowDrawerView, CView)

BEGIN_MESSAGE_MAP(CWorkFlowDrawerView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_COMMAND(ID_DRAW_LINE, &CWorkFlowDrawerView::OnLine)
	ON_COMMAND(ID_DRAW_RECTANGLE, &CWorkFlowDrawerView::OnRectangle)
	ON_COMMAND(ID_DRAW_ELLIPSE, &CWorkFlowDrawerView::OnEllipse)
	ON_COMMAND(ID_DRAW_TEXT, &CWorkFlowDrawerView::OnText)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_CONTEXTMENU()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_CANCEl_DRAW, &CWorkFlowDrawerView::OnCancelDraw)
	ON_COMMAND(ID_EDIT_REDO, &CWorkFlowDrawerView::OnRedo)
	ON_COMMAND(ID_EDIT_UNDO, &CWorkFlowDrawerView::OnUndo)
	ON_UPDATE_COMMAND_UI(ID_DRAW_LINE, &CWorkFlowDrawerView::OnUpdateDrawLine)
	ON_COMMAND(ID_EDIT_DELETE, &CWorkFlowDrawerView::OnEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REDO, &CWorkFlowDrawerView::OnUpdateRedo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, &CWorkFlowDrawerView::OnUpdateUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE, &CWorkFlowDrawerView::OnUpdateEditDelete)
	ON_COMMAND(ID_32785, &CWorkFlowDrawerView::OnMoveUp)
	ON_COMMAND(ID_32786, &CWorkFlowDrawerView::OnMoveDown)
	ON_UPDATE_COMMAND_UI(ID_32785, &CWorkFlowDrawerView::OnUpdateMoveUp)
	ON_UPDATE_COMMAND_UI(ID_32786, &CWorkFlowDrawerView::OnUpdateMoveDown)
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_FILE_SAVE, &CWorkFlowDrawerView::OnFileSave)
	ON_COMMAND(ID_DRAW_LOCK, &CWorkFlowDrawerView::OnDrawLock)
	ON_UPDATE_COMMAND_UI(ID_DRAW_LOCK, &CWorkFlowDrawerView::OnUpdateDrawLock)
END_MESSAGE_MAP()

// CWorkFlowDrawerView 构造/析构

CWorkFlowDrawerView::CWorkFlowDrawerView() noexcept
{
	// TODO: 在此处添加构造代码
	/*CWorkFlowDrawerDoc* pDoc = self.GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;*/
	// 暂时不用Doc类了
	self.entityManager = new MEntityManager();
	self.canvasManager = new MCanvasManager(entityManager);
}

CWorkFlowDrawerView::~CWorkFlowDrawerView()
{
}

BOOL CWorkFlowDrawerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式

	return CView::PreCreateWindow(cs);
}

// CWorkFlowDrawerView 打印

BOOL CWorkFlowDrawerView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CWorkFlowDrawerView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CWorkFlowDrawerView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CWorkFlowDrawerView 诊断

#ifdef _DEBUG
void CWorkFlowDrawerView::AssertValid() const
{
	CView::AssertValid();
}

void CWorkFlowDrawerView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CWorkFlowDrawerDoc* CWorkFlowDrawerView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CWorkFlowDrawerDoc)));
	return (CWorkFlowDrawerDoc*)m_pDocument;
}
#endif //_DEBUG

// CWorkFlowDrawerView 绘图

void CWorkFlowDrawerView::OnDraw(CDC* pDC)
{
	for (MEntity* entity : self.entityManager->getEntityList()) {
		entity->draw(pDC);
	}
	if (self.canvasManager->drawingEntity != nullptr) {
		self.canvasManager->drawingEntity->draw(pDC);
	}
}


// CWorkFlowDrawerView 消息处理程序

// 绘制直线
void CWorkFlowDrawerView::OnLine()
{
	self.canvasManager->cursorType = MCursorType::DRAW_LINE;
	// 不加的话，在“按下”按钮之后，处于PRESSED且非SELECET状态，再触发mouseMove就会绘图.
	// 然而这时候还没有创建对象，所以会出错
	self.canvasManager->mouseStatus = MMouseStatus::RELEASED;
}


// 绘制矩形
void CWorkFlowDrawerView::OnRectangle()
{
	self.canvasManager->cursorType = MCursorType::DRAW_RECTANGLE;
	self.canvasManager->mouseStatus = MMouseStatus::RELEASED;
}


// 绘制椭圆
void CWorkFlowDrawerView::OnEllipse()
{
	
}


// 绘制文本
void CWorkFlowDrawerView::OnText()
{
	
}
void CWorkFlowDrawerView::OnCancelDraw()
{
	self.canvasManager->cursorType = MCursorType::SELECT;
}

void CWorkFlowDrawerView::OnLButtonDown(UINT nFlags, CPoint point)
{
	
	
	self.canvasManager->mouseStatus = MMouseStatus::PRESSED;
	self.canvasManager->setLDownPoint(new CPoint(point));
	self.startPoint = self.endPoint = point;
	
	//if (self.mouseType != MCursorType::SELECT) {
	//	// 绘图状态
	//	self.drawingEntity = MEntityFactory::create(mouseType2EntityType(self.mouseType),
	//		point, MEntity::ENTITY_STATE_SELECTED);
	//	if (self.mouseType == MCursorType::DRAW_LINE 
	//		&& self.connectingEntity != nullptr 
	//		&& self.connectingEntity->isOnConnectPoints(point)) {

	//		point = *self.connectingEntity->getNearConnectPoint(point);
	//		self.connectingEntity->attachOutLine((MLine*)self.drawingEntity, point);
	//	}
	//}
	
	CView::OnLButtonDown(nFlags, point);
}


void CWorkFlowDrawerView::OnMouseMove(UINT nFlags, CPoint point)
{


	CDC* pDC = GetDC();
	// XOR drawing
	pDC->SetROP2(R2_XORPEN);
	CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
	CPen* pen = new CPen(PS_SOLID, 1, RGB(0, 255, 0));
	CPen* oldPen = pDC->SelectObject(pen);
	pDC->Rectangle(self.startPoint.x, self.startPoint.y, self.endPoint.x, self.endPoint.y);
	pDC->Rectangle(self.startPoint.x, self.startPoint.y, point.x, point.y);
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(oldPen);
	ReleaseDC(pDC);
	// self.setCursorStyle(point);
	//if (self.drawingEntity != nullptr) {
	//	// 左键按下且处于"非选择（绘图）"状态
	//	self.drawingEntity->setEndPoint(point);
	//}
	//if (self.connectingEntity != nullptr && 
	//	!(self.mouseType == MCursorType::DRAW_LINE && 
	//		self.connectingEntity->isOnConnectPoints(point))) {
	//	// 当不是 (在画线且鼠标在 选中点 内) 时，将connectingEntity取消
	//	self.connectingEntity->setConnecting(false);
	//	self.connectingEntity = nullptr;
	//}
	//
	//if (self.mouseType == MCursorType::DRAW_LINE) {
	//	// 切换connecing状态的entity
	//	auto entity = self.entityManager->getConnectableEntityOnCurser(&point);
	//	if (connectingEntity != entity && entity != nullptr) {
	//		if (connectingEntity != nullptr)
	//			connectingEntity->setConnecting(false);
	//		connectingEntity = entity;
	//		// connectingEntity->attachInLine(new MLine(1, 1, 1, 1), point);
	//		connectingEntity->setConnecting(true);        
	//	}
	//	self.repaint();
	//} else if (self.mouseStatus == MMouseStatus::PRESSED &&
	//	self.mouseType == MCursorType::SELECT) {
	//	// 画选择框
	//	// draw selecting box 
	//	self.entityManager->setSelectedArea(new CRect(self.startPoint, self.endPoint));
	//	CDC* pDC = GetDC();
	//	// XOR drawing
	//	pDC->SetROP2(R2_XORPEN);
	//	CBrush* pOldBrush = (CBrush*)pDC->SelectStockObject(NULL_BRUSH);
	//	CPen* pen = new CPen(PS_SOLID, 1, RGB(0, 255, 0));
	//	CPen* oldPen = pDC->SelectObject(pen);
	//	pDC->Rectangle(self.startPoint.x, self.startPoint.y, self.endPoint.x, self.endPoint.y);
	//	pDC->Rectangle(self.startPoint.x, self.startPoint.y, point.x, point.y);
	//	pDC->SelectObject(pOldBrush);
	//	pDC->SelectObject(oldPen);
	//	ReleaseDC(pDC);
	//}
	//else if (self.drawingEntity != nullptr) {
	//	self.repaint();
	//}
	//else {
	//}
	
	self.endPoint = point;
	CView::OnMouseMove(nFlags, point);
}


void CWorkFlowDrawerView::OnLButtonUp(UINT nFlags, CPoint point)
{
	self.canvasManager->mouseStatus = MMouseStatus::RELEASED;
	self.endPoint = point;
	self.canvasManager->setLUpPoint(&point);

	/*if (self.mouseType == MCursorType::SELECT) {
		// 处于选择状态下抬起鼠标时，将开始点设置为“选中”
		self.entityManager->clearSelectedStatus();
		if (self.entityManager->isInside(&self.startPoint)) {
			self.entityManager->reverseSelectedStatus(&self.startPoint);
		}
	} else{
		// 绘画状态
		if (self.startPoint.x == point.x && self.startPoint.y == point.y) {
			// 如果开始和结束的点相同，就删除该entity
			delete(self.drawingEntity);
		} else {
			if (self.mouseType == MCursorType::DRAW_LINE &&
				self.connectingEntity != nullptr &&
				self.connectingEntity->isOnConnectPoints(point)) {
				// 如果是画线，需要单独处理
				point = *self.connectingEntity->getNearConnectPoint(point);
				self.drawingEntity->setEndPoint(point);
				self.connectingEntity->attachInLine((MLine*)self.drawingEntity, point);
			}
			self.entityManager->addEntity(self.drawingEntity);
			self.entityManager->clearSelectedStatus();
			self.drawingEntity->select();
		}
		self.drawingEntity = nullptr;
	}*/
	
	self.canvasManager->cursorType = MCursorType::SELECT; // 恢复鼠标状态为“选择”
	self.repaint();
	CView::OnLButtonUp(nFlags, point);
}


void CWorkFlowDrawerView::OnContextMenu(CWnd* /*pWnd*/, CPoint point)
{
	// TODO: 在此处添加消息处理程序代码
}

void CWorkFlowDrawerView::OnUndo()
{
	self.entityManager->undo();
	self.repaint();
}

void CWorkFlowDrawerView::OnRedo()
{
	self.entityManager->redo();
	self.repaint();
}
//int i = 0;
void CWorkFlowDrawerView::OnUpdateDrawLine(CCmdUI* pCmdUI)
{
	// TODO: 在此添加命令更新用户界面处理程序代码
	// 当前鼠标正在画线的时候，将画线按钮设置为disable
	if (self.canvasManager->cursorType == MCursorType::DRAW_LINE) {
		pCmdUI->Enable(false);
	}
	else {
		pCmdUI->Enable(true);
	}
}

void CWorkFlowDrawerView::OnEditDelete()
{
	// TODO: 在此添加命令处理程序代码
	std::vector<MEntity*> entities = self.entityManager->getSelectedEntities();
	self.entityManager->remove(entities);
	CRect rect;
	GetClientRect(rect);
	self.InvalidateRect(rect);
}

void CWorkFlowDrawerView::OnUpdateRedo(CCmdUI* pCmdUI)
{
	// TODO: 在此添加命令更新用户界面处理程序代码
	if (self.entityManager->existsRedo()) {
		pCmdUI->Enable(true);
	}
	else {
		pCmdUI->Enable(false);
	}
}

void CWorkFlowDrawerView::OnUpdateUndo(CCmdUI* pCmdUI)
{
	// TODO: 在此添加命令更新用户界面处理程序代码
	if (self.entityManager->existsUndo()) {
		pCmdUI->Enable(true);
	}
	else {
		pCmdUI->Enable(false);
	}
}

void CWorkFlowDrawerView::OnUpdateEditDelete(CCmdUI* pCmdUI)
{
	// TODO: 在此添加命令更新用户界面处理程序代码
	if (self.entityManager->getSelectedEntities().size() != 0) {
		pCmdUI->Enable(true);
	}
	else {
		pCmdUI->Enable(false);
	}
}

void CWorkFlowDrawerView::OnMoveUp()
{
	self.entityManager->moveUpSelectedEntities();
	self.repaint();
}


void CWorkFlowDrawerView::OnMoveDown()
{
	self.entityManager->moveDownSelectedEntities();
	self.repaint();
}


void CWorkFlowDrawerView::OnUpdateMoveUp(CCmdUI* pCmdUI)
{
	if (self.entityManager->couldMoveUpSelectedEntities())
		pCmdUI->Enable(true);
	else
		pCmdUI->Enable(false);
}


void CWorkFlowDrawerView::OnUpdateMoveDown(CCmdUI* pCmdUI)
{
	if (self.entityManager->couldMoveDownSelectedEntities())
		pCmdUI->Enable(true);
	else
		pCmdUI->Enable(false);
}


BOOL CWorkFlowDrawerView::OnEraseBkgnd(CDC* pDC)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	CRect clientRect;
	self.GetClientRect(&clientRect);
	CBrush clientBrush(RGB(200, 200, 200));
	// pDC->(RGB(0, 255, 0));
	pDC->FillRect(&clientRect, &clientBrush);

	self.middleX = (clientRect.TopLeft().x + clientRect.BottomRight().x) / 2;
	self.leftX = middleX - 525;
	self.rightX = middleX + 525;
	self.topY = 10;
	self.bottomY = 1495;

	CRect a4Rect(leftX, topY, rightX, bottomY);
	CBrush a4Brush (RGB(255, 255, 255));
	pDC->FillRect(&a4Rect, &a4Brush);

	int netSize = 10;
	CPen thinPen;
	thinPen.CreatePen(PS_SOLID, 1, RGB(200, 200, 200));
	CPen thickPen;
	thickPen.CreatePen(PS_SOLID, 2, RGB(150, 150, 150));
	auto oldPen = pDC->SelectObject(thinPen);
	int count = 0;
	for (int i = leftX, count = 0; i < rightX; i += netSize, count++) {
		if (count % 5 == 4) {
			count = 0;
			pDC->SelectObject(thickPen);
			pDC->MoveTo(i, topY);
			pDC->LineTo(i, bottomY);
		}
		else {
			pDC->SelectObject(thinPen);
			pDC->MoveTo(i, topY);
			pDC->LineTo(i, bottomY);
		}
	}
	for (int j = topY, count = 0; j < bottomY; j += netSize, count++) {
		if (count % 5 == 4) {
			count = 0;
			pDC->SelectObject(thickPen);
			pDC->MoveTo(leftX, j);
			pDC->LineTo(rightX, j);
		}
		else {
			pDC->SelectObject(thinPen);
			pDC->MoveTo(leftX, j);
			pDC->LineTo(rightX, j);
		}
	}
	pDC->SelectObject(oldPen);

	return false;
}

//#include <afxdlgs.h>
//#include <string>
//bool fileOpen(std::string* pPath, const std::string& defaultName, const std::string& defaultExtension, const std::string& extensions)
//{
//	//return false;
//
//	CFileDialog dlg(
//		true,                                   // true for File Open dialog box
//		defaultExtension.c_str(),               // The default file name extension
//		defaultName.c_str(),                    // The default file name
//		OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR,    // bunch of flags http://msdn.microsoft.com/en-us/library/wh5hz49d.aspx
//		extensions.c_str()
//	);
//
//	auto result = dlg.DoModal();
//	if (result != IDOK) return false; // failed
//	// pPath->assign(dlg.GetPathName());
//	return true;
//}
#include<string>
#include "Work_Flow_DrawerDoc.h"
void CWorkFlowDrawerView::OnFileSave()
{
	// TODO: 在此添加命令处理程序代码
	CFileDialog dlg(false, _T("*.lhy"), 
		NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		_T("file (*.lhy)|*.lhy|"), NULL);
	dlg.m_ofn.lpstrTitle = _T("save lhy file");

	
	if (dlg.DoModal() != IDOK)
		return;
	else {
		CString  mPath = dlg.GetPathName();
		int result = MessageBox(mPath, TEXT("HELLO"), MB_YESNO);
		CFile file;
		file.Open(mPath, CFile::modeCreate | CFile::modeWrite);
		std::string str("Hello world lhy");
		file.Write(str.c_str(), str.size());
		file.Close();
		
		auto pDoc = self.GetDocument();
		pDoc->SetTitle(mPath);
	}
	
}


void CWorkFlowDrawerView::OnDrawLock()
{
	// TODO: 在此添加命令处理程序代码
	self.canvasManager->cursorType = MCursorType::SELECT;
}


void CWorkFlowDrawerView::OnUpdateDrawLock(CCmdUI* pCmdUI)
{
	// TODO: 在此添加命令更新用户界面处理程序代码
	pCmdUI->SetCheck(false);
}
HCURSOR crossCursor = LoadCursor(NULL, IDC_SIZEALL);
HCURSOR arrowCursor = LoadCursor(NULL, IDC_ARROW);
HCURSOR nwseCursor = LoadCursor(NULL, IDC_SIZENWSE);
HCURSOR neswCursor = LoadCursor(NULL, IDC_SIZENESW);
HCURSOR weCursor = LoadCursor(NULL, IDC_SIZEWE);
HCURSOR nsCursor = LoadCursor(NULL, IDC_SIZENS);


void CWorkFlowDrawerView::setCursorStyle(CPoint& point) {
	int status = (int)self.entityManager->getPointStatus(point);
	switch (status) {
	case 0:
		SetCursor(arrowCursor);
		break;
	case 1:
		SetCursor(crossCursor);
		break;

	case 2:
	case 6:
		SetCursor(nwseCursor);
		break;
	case 3:
	case 7:
		SetCursor(nsCursor);
		break;
	case 4:
	case 8:
		SetCursor(neswCursor);
		break;
	case 5:
	case 9:
		SetCursor(weCursor);
		break;
	}
}