#include"MEntity.h"
#include"MEntityManager.h"
#include<algorithm>

bool greaterSort(MEntity* a, MEntity* b) {
	return a->getPosition() > b->getPosition();
}
bool lessSort(MEntity* a, MEntity* b) {
	return a->getPosition() < b->getPosition();
}

void MEntityManager::setSelected(CPoint* point) {

	MEntity* selected_entity = nullptr;
	for (MEntity* entity : self.entityList) {
		if (entity->isInside(point)) {
			selected_entity = entity;
		}
	}
	if (selected_entity != nullptr) {
		selected_entity->select();
	}
}
MEntity* MEntityManager::setSelectedAndOthersUnselected(CPoint* point) {
	MEntity* selected_entity = nullptr;
	for (MEntity* entity : self.entityList) {
		if (entity->isInside(point)) {
			selected_entity = entity;
		}
		if (entity->isSelected()) {
			entity->unselect();
		}
	}
	if (selected_entity != nullptr) {
		selected_entity->select();
	}
	return selected_entity;
}
void MEntityManager::setSelectedArea(CRect* rect) {
	
}

void MEntityManager::reverseSelectedStatus(CPoint* point) {
	MEntity* selected_entity = nullptr;
	for (MEntity* entity : self.entityList) {
		if (entity->isInside(point)) {
			selected_entity = entity; // the top entity
		}
	}
	if (selected_entity != nullptr) {
		selected_entity->isSelected() ? selected_entity->unselect() : selected_entity->select();
	}
}

bool MEntityManager::isInside(CPoint* point) {
	for (MEntity* entity : self.entityList) {
		if (entity->isInside(point)) {
			return true;
		}
	}
	return false;
}

void MEntityManager::clearSelectedStatus() {
	for (MEntity* entity : self.entityList) {
		entity->unselect();
	}
}

// 0�������ڣ�1�����ڵ��ǲ���ԲȦ�ڣ�2-8�ֱ���������ϡ��ϡ����ϡ�����СȦ��
int MEntityManager::getPointStatus(CPoint& point) {
	int status;
	for (auto e : self.entityList) {
		status = e->getPointStatus(point);
		if (status != 0) {
			return status;
		}
	}
	return 0;
}

void MEntityManager::_addEntity(MEntity* entity) {
	if (entity->hasPosition()) {
		std::vector<MEntity*>::iterator ite = self.entityList.begin() + entity->getPosition();
		self.entityList.insert(ite, entity);
		ite = self.entityList.begin() + entity->getPosition();
		//������һ����iteָ��entity������Ҫ���º���entity
		for (++ite; ite != self.entityList.end(); ++ite) {
			(*ite)->setPosition((*ite)->getPosition() + 1);
		}
	}
	else {
		//����û�б����ù�λ�ã���Ҫ����positionΪ���һ��
		entity->setPosition(self.entityList.size());
		self.entityList.push_back(entity);
	}
}

void MEntityManager::_addEntity(std::vector<MEntity*> entities) {
	std::sort(entities.begin(), entities.end(), lessSort);
	for (MEntity* e : entities) {
		self._addEntity(e);
	}
}

void MEntityManager::addEntity(MEntity* entity) {
	self._addEntity(entity);
	if (self.isRecordingOperation) {
		self.operationManager->addOperation(new MAddOperation(entity));
	}
}

void MEntityManager::_remove(MEntity* entity) {
	if (self.contains(entity)) {
		self.entityList.erase(self.entityList.begin() + entity->getPosition());
		for (auto it = self.entityList.begin() + entity->getPosition(); it != self.entityList.end(); ++it) {
			(*it)->setPosition((*it)->getPosition() - 1);
		}
	}
}

void MEntityManager::_remove(std::vector<MEntity*> entities) {
	for (auto entity : entities) {
		self._remove(entity);
	}
}

void MEntityManager::remove(MEntity* entity) {
	if (self.contains(entity)) {
		self._remove(entity);
		self.operationManager->addOperation(new MDeleteOperation(entity));
	}
	
}

void MEntityManager::remove(std::vector<MEntity*> entities) {
	std::sort(entities.begin(), entities.end(), greaterSort);
	self._remove(entities);
	// TODO ����в�������entity����Ӧ�üӵ�operation��
	self.operationManager->addOperation(new MDeleteOperation(entities));
	
}

bool MEntityManager::contains(MEntity* entity) {
	int i = 0;
	for (MEntity* e : self.entityList) {
		if (e->equals(entity)) return true; // ������ƣ���֤λ�õ���ȷ
		i++;
	}
	return false;
}

std::vector<MEntity*> MEntityManager::getSelectedEntities() {
	std::vector<MEntity*> ans;
	for (MEntity* entity : self.entityList) {
		if (entity->isSelected()) {
			ans.push_back(entity);
		}
	}
	return ans;
}

void MEntityManager::undo() {
	// �õ����һ�β����������е�afterɾ�����������е�before
	MOperation* ope = self.operationManager->getUndoOperation();
	if (ope != nullptr) {
		self._remove(ope->entitiesAfter()); //���ﷵ�ص������ǿ�vector���������ǿ�ָ��
		self._addEntity(ope->entitiesBefore());
	}
}

void MEntityManager::redo() {
	MOperation* ope = self.operationManager->getRedoOperation();
	if (ope != nullptr) {
		self._remove(ope->entitiesBefore()); //���ﷵ�ص������ǿ�vector���������ǿ�ָ��
		self._addEntity(ope->entitiesAfter());
	}
}

void MEntityManager::moveUpSelectedEntities() {
	if (!self.entityList.empty()) {
		MEntity* temp;
		std::vector<MEntity*> before;
		std::vector<MEntity*> after;
		for (auto it = self.entityList.rbegin() + 1; it != self.entityList.rend(); ++it) {
			if ((*it)->isSelected() && !(*(it - 1))->isSelected()) {
				before.push_back(*it);
				*it = (*it)->copy();
				(*it)->setPosition((*it)->getPosition() + 1);
				after.push_back(*it);
				(*(it - 1))->setPosition((*(it - 1))->getPosition() - 1);
				temp = *it;
				*it = *(it - 1);
				*(it - 1) = temp;
				
			}
		}
		if (!before.empty()) {
			self.operationManager->addOperation(new MChangeLayerOperation(before, after));
		}
	}
}
void MEntityManager::moveDownSelectedEntities() {
	if (!self.entityList.empty()) {
		MEntity* temp;
		std::vector<MEntity*> before;
		std::vector<MEntity*> after;
		for (auto it = self.entityList.begin() + 1; it != self.entityList.end(); ++it) {
			if ((*it)->isSelected() && !(*(it - 1))->isSelected()) {
				before.push_back(*it);
				*it = (*it)->copy();
				(*it)->setPosition((*it)->getPosition() - 1);
				after.push_back(*it);
				(*(it - 1))->setPosition((*(it - 1))->getPosition() + 1);
				temp = *it;
				*it = *(it - 1);
				*(it - 1) = temp;
			}
		}
		if (!before.empty()) {
			self.operationManager->addOperation(new MChangeLayerOperation(before, after));
		}
	}
}
bool MEntityManager::couldMoveUpSelectedEntities() {
	// Ч�ʼ������
	if (!self.entityList.empty()) {
		for (auto it = self.entityList.rbegin() + 1; it != self.entityList.rend(); ++it) {
			if ((*it)->isSelected() && !(*(it - 1))->isSelected()) {
				return true;
			}
		}
	}
	return false;
}
bool MEntityManager::couldMoveDownSelectedEntities() {
	if (!self.entityList.empty()) {
		for (auto it = self.entityList.begin() + 1; it != self.entityList.end(); ++it) {
			if ((*it)->isSelected() && !(*(it - 1))->isSelected()) {
				return true;
			}
		}
	}
	return false;
}

MRectangle* MEntityManager::getConnectableEntityOnCurser(CPoint* point) {
	MRectangle* ans = nullptr;
	for (auto e : self.entityList) {
		if (e->isInside(point) && dynamic_cast<MRectangle*>(e)) {
			ans = (MRectangle*)e;
		}
	}
	return ans;
}