﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 WorkFlowDrawer.rc 使用
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_WorkFlowDrawerTYPE          130
#define IDR_TOOLBAR                     310
#define ID_DRAW_LINE                    32771
#define ID_DRAW_RECTANGLE               32772
#define ID_DRAW_ELLIPSE                 32773
#define ID_DRAW_TEXT                    32774
#define ID_32776                        32776
#define ID_                             32777
#define ID_CANCEl_DRAW                  32778
#define ID_Menu                         32779
#define ID_REDO                         32780
#define ID_UNDO                         32781
#define ID_32782                        32782
#define ID_DELETE                       32783
#define ID_EDIT_DELETE                  32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_BUTTON32791                  32791
#define ID_BUTTON32792                  32792
#define ID_32795                        32795
#define ID_32796                        32796
#define ID_DRAW_LOCK                    32797

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32798
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
