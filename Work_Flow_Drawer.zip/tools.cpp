#include "tools.h"
MEntityType mouseType2EntityType(MCursorType type) {
	switch (type) {
	case(MCursorType::DRAW_LINE): return MEntityType::LINE;
	case(MCursorType::DRAW_RECTANGLE): return MEntityType::RECTANGLE;
	case(MCursorType::DRAW_ELLIPSE): return MEntityType::ELLIPSE;
	case(MCursorType::DRAW_TEXT): return MEntityType::TEXT;
	default: return MEntityType::LINE; //Ϊ���������棬��ʱ����
	}
}