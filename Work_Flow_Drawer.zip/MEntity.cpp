#include "MEntity.h"

MEntity::MEntity(CPoint start, CPoint end, int statusCode, int _position) 
	: MDrawable(start, end) {
	self.setStatusCode(statusCode);
	self.position = _position;
	
}

void MEntity::draw(CDC* dc) {
	self.drawSelectPoints(dc);
}

void MEntity::setStatusCode(int code) {
	self.pen.DeleteObject();
	self.statusCode = code;
	if (self.statusCode & ENTITY_STATE_SELECTED) {
		self.pen.CreatePen(self.DEFAULT_PEN_TYPE, self.THICK_PEN_WIDTH, self.BLACK);
	}
	else if (self.statusCode == ENTITY_STATE_NORMAL) {
		self.pen.CreatePen(self.DEFAULT_PEN_TYPE, self.THIN_PEN_WIDTH, self.BLACK);
	}
}

void MEntity::drawSelectPoints(CDC* dc) {
	if (!(self.statusCode & self.ENTITY_STATE_SELECTED)) {
		return;
	}
	std::vector<CPoint*> selectPoints = self.getSelectPoints();
	for (CPoint* p : selectPoints) {
		dc->Ellipse(p->x - self.SELECT_CIRCLE_RADIUS,
			p->y - self.SELECT_CIRCLE_RADIUS,
			p->x + self.SELECT_CIRCLE_RADIUS,
			p->y + self.SELECT_CIRCLE_RADIUS);
	}
}
void MRectangle::drawConnectPoints(CDC* dc) {
	if (!(self.statusCode & self.ENTITY_STATE_CONNECTING)) {
		return;
	}
	std::vector<CPoint*> connectPoints = self.getConnectPoints();

	CBrush connectPointBrush(self.GREY);
	auto oldPen = dc->SelectObject(connectPointBrush);
	for (CPoint* p : connectPoints) {
		dc->Ellipse(p->x - self.SELECT_CIRCLE_RADIUS,
			p->y - self.SELECT_CIRCLE_RADIUS,
			p->x + self.SELECT_CIRCLE_RADIUS,
			p->y + self.SELECT_CIRCLE_RADIUS);
	}
	dc->SelectObject(oldPen);
}

bool MRectangle::isOnConnectPoints(CPoint& point) {
	for (auto p : self.getConnectPoints()) {
		if ((p->x - point.x) * (p->x - point.x) + (p->y - point.y) * (p->y - point.y)
			< self.SELECT_CIRCLE_RADIUS * self.SELECT_CIRCLE_RADIUS) {
			return true;
		}
	}
	return false;
}
CPoint* MRectangle::getNearConnectPoint(CPoint& point) {
	for (auto p : self.getConnectPoints()) {
		if ((p->x - point.x) * (p->x - point.x) + (p->y - point.y) * (p->y - point.y)
			< self.SELECT_CIRCLE_RADIUS * self.SELECT_CIRCLE_RADIUS) {
			return p;
		}
	}
	return nullptr;
}
void MRectangle::attachOutLine(MLine* line, CPoint& connectPoint) {
	if (connectPoint.x > (self.startPoint.x + self.endPoint.x) / 2) {
		self.outLines[1].push_back(line);
	}
	else if (connectPoint.x < (self.startPoint.x + self.endPoint.x) / 2) {
		self.outLines[3].push_back(line);
	}
	else if (connectPoint.y > (self.startPoint.y + self.endPoint.y) / 2) {
		self.outLines[0].push_back(line);
	}
	else {
		self.outLines[2].push_back(line);
	}
}
void MRectangle::attachInLine(MLine* line, CPoint& connectPoint) {
	if (connectPoint.x > (self.startPoint.x + self.endPoint.x) / 2) {
		self.inLines[1].push_back(line);
	}
	else if (connectPoint.x < (self.startPoint.x + self.endPoint.x) / 2) {
		self.inLines[3].push_back(line);
	}
	else if (connectPoint.y > (self.startPoint.y + self.endPoint.y) / 2) {
		self.inLines[0].push_back(line);
	}
	else {
		self.inLines[2].push_back(line);
	}
}


void MRectangle::draw(CDC* dc) {
	CPen* oldPen = dc->SelectObject(&self.pen);
	dc->Rectangle(self.startPoint.x, self.startPoint.y, self.endPoint.x, self.endPoint.y);
	self.drawSelectPoints(dc);
	self.drawConnectPoints(dc);
	dc->DrawText(CString("Hello world"), &CRect(self.startPoint, self.endPoint), DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	dc->SelectObject(oldPen);
	
}

bool MEntity::equals(MEntity* e) {
	return self.startPoint == e->startPoint && self.endPoint == e->endPoint
		&& self.statusCode == e->statusCode && self.position == e->position;
}

std::vector<CPoint*> MRectangle::getSelectPoints(void) {
	if (!self.selectPoints.empty()) {
		for (auto p : self.selectPoints) {
			delete(p);
		}
		self.selectPoints.clear();
	}
	
	self.selectPoints.push_back(new CPoint(self.startPoint.x, self.startPoint.y));
	self.selectPoints.push_back(new CPoint(self.startPoint.x, self.endPoint.y));
	self.selectPoints.push_back(new CPoint(self.endPoint.x, self.startPoint.y));
	self.selectPoints.push_back(new CPoint(self.endPoint.x, self.endPoint.y));

	self.selectPoints.push_back(new CPoint((self.startPoint.x + self.endPoint.x) / 2, self.startPoint.y));
	self.selectPoints.push_back(new CPoint((self.startPoint.x + self.endPoint.x) / 2, self.endPoint.y));
	self.selectPoints.push_back(new CPoint(self.startPoint.x, (self.startPoint.y + self.endPoint.y) / 2));
	self.selectPoints.push_back(new CPoint(self.endPoint.x, (self.startPoint.y + self.endPoint.y) / 2));

	return self.selectPoints;
}

std::vector<CPoint*> MRectangle::getConnectPoints() {
	if (!self.connectPoints.empty()) {
		for (auto p : self.connectPoints) {
			delete(p);
		}
		self.connectPoints.clear();
	}
	self.connectPoints.push_back(new CPoint((self.startPoint.x + self.endPoint.x) / 2, self.startPoint.y));
	self.connectPoints.push_back(new CPoint((self.startPoint.x + self.endPoint.x) / 2, self.endPoint.y));
	self.connectPoints.push_back(new CPoint(self.startPoint.x, (self.startPoint.y + self.endPoint.y) / 2));
	self.connectPoints.push_back(new CPoint(self.endPoint.x, (self.startPoint.y + self.endPoint.y) / 2));
	

	return self.connectPoints;
}

bool MRectangle::isInside(CPoint* point) {
	return (point->x >= self.startPoint.x && point->x <= self.endPoint.x ||
			point->x >= self.endPoint.x && point->x <= self.startPoint.x) &&
			(point->y >= self.startPoint.y && point->y <= self.endPoint.y ||
			point->y >= self.endPoint.y && point->y <= self.startPoint.y);
}
double distance(CPoint& px, CPoint& py) {
	double ans = sqrt((px.x - py.x) * (px.x - py.x) + (px.y - py.y) * (px.y - py.y));
	if (ans < 10) {
		ans += 1;
	}
	return ans;
}
int MRectangle::getPointStatus(CPoint& point) {
	int centerX = (self.startPoint.x + self.endPoint.x) / 2;
	int centerY = (self.startPoint.y + self.endPoint.y) / 2;

	if (distance(point, CPoint(centerX - width / 2, centerY - height / 2)) < self.SELECT_CIRCLE_RADIUS) {
		return 2;
	}
	else if (distance(point, CPoint(centerX, centerY - height / 2)) < self.SELECT_CIRCLE_RADIUS) {
		return 3;
	}
	else if (distance(point, CPoint(centerX + width / 2, centerY - height / 2)) < self.SELECT_CIRCLE_RADIUS) {
		return 4;
	}
	else if (distance(point, CPoint(centerX + width / 2, centerY)) < self.SELECT_CIRCLE_RADIUS) {
		return 5;
	}
	else if (distance(point, CPoint(centerX + width / 2, centerY + height / 2)) < self.SELECT_CIRCLE_RADIUS) {
		return 6;
	}
	else if (distance(point, CPoint(centerX, centerY + height / 2)) < self.SELECT_CIRCLE_RADIUS) {
		return 7;
	}
	else if (distance(point, CPoint(centerX - width / 2, centerY + height / 2)) < self.SELECT_CIRCLE_RADIUS) {
		return 8;
	}
	else if (distance(point, CPoint(centerX - width / 2, centerY)) < self.SELECT_CIRCLE_RADIUS) {
		return 9;
	}
	
	if (self.isInside(&point)) {
		return 1;
	}
	else {
		return 0;
	}
}

void MRectangle::setConnecting(bool b) {
	if (b) {
		self.statusCode |= ENTITY_STATE_CONNECTING;
	}
	else {
		if (self.statusCode & ENTITY_STATE_CONNECTING) {
			self.statusCode -= ENTITY_STATE_CONNECTING;
		}
		// �Ҳ�����Ϊʲô����Ĳ���
		// self.statusCode &= (!ENTITY_STATE_CONNECTING);
	}
}


void MLine::draw(CDC* dc) {
	CPen* oldPen = dc->SelectObject(&self.pen);
	dc->MoveTo(self.startPoint);
	dc->LineTo(self.endPoint);
	self.drawSelectPoints(dc);
	dc->SelectObject(oldPen);
}

std::vector<CPoint*> MLine::getSelectPoints(void) {
	if (!self.selectPoints.empty()) {
		for (auto p : self.selectPoints) {
			delete(p);
		}
		self.selectPoints.clear();
	}
	self.selectPoints.push_back(new CPoint(self.startPoint.x, self.startPoint.y));
	self.selectPoints.push_back(new CPoint(self.endPoint.x, self.endPoint.y));
	self.selectPoints.push_back(new CPoint((self.startPoint.x + self.endPoint.x) / 2, (self.startPoint.y + self.endPoint.y) / 2));
	return self.selectPoints;
}

bool MLine::isInside(CPoint* point) {
	double x1 = self.startPoint.x, y1 = self.startPoint.y;
	double x2 = self.endPoint.x, y2 = self.endPoint.y;
	double k = (y1 - y2) / (x1 - x2), b = (x1 * y2 - x2 * y1) / (x1 - x2);
	double d = abs(k * point->x - point->y + b) / sqrt(k * k + 1);
	if (d > self.SELECT_RANGE_LEN) {
		return false;
	}
	else {
		return (point->x >= self.startPoint.x && point->x <= self.endPoint.x ||
			point->x >= self.endPoint.x && point->x <= self.startPoint.x) &&
			(point->y >= self.startPoint.y && point->y <= self.endPoint.y ||
				point->y >= self.endPoint.y && point->y <= self.startPoint.y);
	}
}

int MLine::getPointStatus(CPoint& point) {
	return 0;
}


MEntity* MEntityFactory::create(MEntityType type, CPoint point, int entityStatusCode) {
	switch (type) {
	case MEntityType::RECTANGLE:
		return new MRectangle(point, point, entityStatusCode);
	//case MEntityType::ELLIPSE:
	//	return new MEllipse(point, point, entityStatusCode);
	case MEntityType::LINE:
		return new MLine(point, point, entityStatusCode);
	case MEntityType::TEXT:
		return nullptr;
	default:
		return nullptr;
	}
}

//void MEllipse::draw(CDC* dc) {
//	CPen* oldPen = dc->SelectObject(&self.pen);
//	dc->Ellipse(self.startPoint.x, self.startPoint.y, self.endPoint.x, self.endPoint.y);
//	self.drawSelectPoints(dc);
//	self.drawConnectPoints(dc);
//	dc->SelectObject(oldPen);
//}
//
//std::vector<CPoint*> MEllipse::getSelectPoints(void) {
//	if (!self.selectPoints.empty()) {
//		for (auto p : self.selectPoints) {
//			delete(p);
//		}
//		self.selectPoints.clear();
//	}
//	self.selectPoints.push_back(new CPoint(self.startPoint.x, self.startPoint.y));
//	self.selectPoints.push_back(new CPoint(self.startPoint.x, self.endPoint.y));
//	self.selectPoints.push_back(new CPoint(self.endPoint.x, self.startPoint.y));
//	self.selectPoints.push_back(new CPoint(self.endPoint.x, self.endPoint.y));
//
//	self.selectPoints.push_back(new CPoint((self.startPoint.x + self.endPoint.x) / 2, self.startPoint.y));
//	self.selectPoints.push_back(new CPoint((self.startPoint.x + self.endPoint.x) / 2, self.endPoint.y));
//	self.selectPoints.push_back(new CPoint(self.startPoint.x, (self.startPoint.y + self.endPoint.y) / 2));
//	self.selectPoints.push_back(new CPoint(self.endPoint.x, (self.startPoint.y + self.endPoint.y) / 2));
//
//	return self.selectPoints;
//}
//
//std::vector<CPoint*> MEllipse::getConnectPoints() {
//	if (!self.connectPoints.empty()) {
//		for (auto p : self.connectPoints) {
//			delete(p);
//		}
//		self.connectPoints.clear();
//	}
//	self.connectPoints.push_back(new CPoint((self.startPoint.x + self.endPoint.x) / 2, self.startPoint.y));
//	self.connectPoints.push_back(new CPoint((self.startPoint.x + self.endPoint.x) / 2, self.endPoint.y));
//	self.connectPoints.push_back(new CPoint(self.startPoint.x, (self.startPoint.y + self.endPoint.y) / 2));
//	self.connectPoints.push_back(new CPoint(self.endPoint.x, (self.startPoint.y + self.endPoint.y) / 2));
//	return self.connectPoints;
//}
//
//bool MEllipse::isInside(CPoint* point) {
//	// l: left  t: top  r: right  b: buttom
//	int ltx = self.startPoint.x < self.endPoint.x ? self.startPoint.x : self.endPoint.x;
//	int lty = self.startPoint.y < self.endPoint.y ? self.startPoint.y : self.endPoint.y;
//	int rbx = self.startPoint.x > self.endPoint.x ? self.startPoint.x : self.endPoint.x;
//	int rby = self.startPoint.y > self.endPoint.y ? self.startPoint.y : self.endPoint.y;
//	int width = rbx - ltx;
//	int height = rby - lty;
//	if (width < height) {
//		double a = height / 2.0, b = width / 2.0;
//		double c = sqrt(a * a - b * b);
//		double c1x = 1.0 * ltx + width / 2.0;
//		double c1y = lty + a - c;
//		double c2x = 1.0 * ltx + width / 2.0;
//		double c2y = rby - a + c;
//		double d1 = sqrt((point->x - c1x) * (point->x - c1x) + (point->y - c1y) * (point->y - c1y));
//		double d2 = sqrt((point->x - c2x) * (point->x - c2x) + (point->y - c2y) * (point->y - c2y));
//		if (d1 + d2 < 2 * a) {
//			return true;
//		}
//		else {
//			return false;
//		}
//	}
//	else {
//		double b = height / 2.0, a = width / 2.0;
//		double c = sqrt(a * a - b * b);
//		double c1x = ltx + a - c;
//		double c1y = 1.0 * lty + height / 2.0;
//		double c2x = rbx - a + c;
//		double c2y = 1.0 * lty + height / 2.0;
//		double d1 = sqrt((point->x - c1x) * (point->x - c1x) + (point->y - c1y) * (point->y - c1y));
//		double d2 = sqrt((point->x - c2x) * (point->x - c2x) + (point->y - c2y) * (point->y - c2y));
//		if (d1 + d2 < 2 * a) {
//			return true;
//		}
//		else {
//			return false;
//		}
//	}
//}
