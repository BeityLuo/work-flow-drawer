#pragma once
#ifndef TOOLS
#define TOOLS
#include"MEntityManager.h"
#define self (*this)
#include "MCanvasManager.h"
enum class MCursorType {
	DRAW_LINE, DRAW_RECTANGLE, DRAW_ELLIPSE, DRAW_TEXT, SELECT
};

enum class MMouseStatus {
	PRESSED, RELEASED
};
MEntityType mouseType2EntityType(MCursorType type);
#endif