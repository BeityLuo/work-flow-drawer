#pragma once
#include "MEntity.h"
class MEntityDrawer {
private:
public:
	void draw(MEntity* entity);
};