#pragma once
#include "MDrawable.h"
#include "MConnectable.h"
#include <atltypes.h>

#include<vector>
#ifndef MENTITY
#define MENTITY




#define self (*this)

enum class MEntityType {
	RECTANGLE, ELLIPSE, LINE, TEXT
};

class MLine;



class MEntity : public MDrawable{
public:
	static const int ENTITY_STATE_NORMAL		= 0x00000000;
	static const int ENTITY_STATE_SELECTED		= 0x00000001;
	static const int ENTITY_STATE_FOCUSED		= 0x00000002;
	static const int ENTITY_STATE_CONNECTING	= 0x00000004;
	int statusCode = ENTITY_STATE_NORMAL;

protected:
	int position;
	std::vector<CPoint*> selectPoints;
	
private:
	void setStatusCode(int code);

public:
	MEntity(CPoint start, CPoint end, int statusCode = ENTITY_STATE_SELECTED, int position = -1);
	bool isSelected() { return self.statusCode & ENTITY_STATE_SELECTED; }
	void select() { setStatusCode(ENTITY_STATE_SELECTED); }
	void unselect() { setStatusCode(ENTITY_STATE_NORMAL); }

	virtual void draw(CDC* dc);
	virtual std::vector<CPoint*> getSelectPoints() = 0;
	void drawSelectPoints(CDC* dc);

	virtual bool isInside(CPoint* point) = 0;
	
	int getPosition() { return self.position; }
	void setPosition(int p) { self.position = p; }
	bool hasPosition() { return self.position != -1; }

	virtual MEntity* copy() = 0;
	bool equals(MEntity* entity);

	virtual int getPointStatus(CPoint& point) = 0;
	
};

class MRectangle : public MEntity{
private:
	std::vector<CPoint*> connectPoints;

	int width, height;

	// �ĸ�connect�㣬�����0�ţ�˳��վ����
	std::vector<std::vector<MLine*>> inLines;
	std::vector<std::vector<MLine*>> outLines;
public:
	MRectangle(CPoint start, CPoint end, int statusCode = ENTITY_STATE_SELECTED, int position = -1) :
		MEntity(start, end, statusCode, position) {
		width = start.x - end.x;
		height = start.y - end.y;
		width = width > 0 ? width : -width;
		height = height > 0 ? height : -height;
		for (int i = 0; i < 4; i++) {
			self.outLines.push_back(std::vector<MLine*>());
			self.inLines.push_back(std::vector<MLine*>());
		}
	}
	// From MEntity
	std::vector<CPoint*> getSelectPoints(void);
	void draw(CDC* dc);
	bool isInside(CPoint* point);
	MEntity* copy() { return new MRectangle(self.startPoint, self.endPoint, self.statusCode, self.position); }

	// From MConnectable
	std::vector<CPoint*> getConnectPoints() ;
	bool isOnConnectPoints(CPoint& point) ;
	CPoint* getNearConnectPoint(CPoint& point) ;
	void attachOutLine(MLine* line, CPoint& connectPoint) ;
	void attachInLine(MLine* line, CPoint& connectPoint) ;
	void setConnecting(bool b);

	void drawConnectPoints(CDC* dc);

	int getPointStatus(CPoint& point);

	void setEndPoint(CPoint end) {
		width = self.startPoint.x - end.x;
		height = self.startPoint.y - end.y;
		width = width > 0 ? width : -width;
		height = height > 0 ? height : -height;
		MDrawable::setEndPoint(end);
	}
};

class MEllipse {
//public:
//	MEllipse(CPoint start, CPoint end, int statusCode = ENTITY_STATE_SELECTED, int position = -1) :
//		MEntity(start, end, statusCode, position) {}
//	void draw(CDC* dc);
//	std::vector<CPoint*> getSelectPoints(void);
//	std::vector<CPoint*> getConnectPoints();
//	
//	bool isInside(CPoint* point);
//	MEntity* copy() { return new MEllipse(self.startPoint, self.endPoint, self.statusCode, self.position); }
};

class MLine : public MEntity {
public:
	static const int SELECT_RANGE_LEN = 4;
public:
	MLine(CPoint start, CPoint end, int statusCode = ENTITY_STATE_SELECTED, int position = -1) :
       		MEntity(start, end, statusCode, position) {}
	void draw(CDC* dc);
	std::vector<CPoint*> getSelectPoints(void);
	bool isInside(CPoint* point);
	MEntity* copy() { return new MLine(self.startPoint, self.endPoint, self.statusCode, self.position); }
	
	int getPointStatus(CPoint& point);
};



class MEntityFactory {
public:
	static MEntity* create(MEntityType type, CPoint point, int entityStatusCode);
};
#endif // !MENTITY